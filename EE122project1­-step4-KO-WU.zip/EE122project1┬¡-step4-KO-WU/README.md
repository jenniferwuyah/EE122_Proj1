1. Jessica Ko; Jennifer Wu
2. jessicak@berkeley.edu, jenniferwu0621@gmail.com
3. Linux (Ubuntu 14.04.2)
4. To compile, rule “make”.